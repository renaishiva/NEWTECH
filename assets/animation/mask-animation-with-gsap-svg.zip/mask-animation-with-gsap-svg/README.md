# Mask animation with GSAP & SVG

A Pen created on CodePen.io. Original URL: [https://codepen.io/martifenosa/pen/OBbQYr](https://codepen.io/martifenosa/pen/OBbQYr).

Three words slider with Greensock, svg and mask transitions.